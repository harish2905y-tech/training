public class Solution {
    public int minSubArrayLen(int target, int[] nums) {
        int n = nums.length;
        int start = 0;
        int currentSum = 0;
        int minLen = Integer.MAX_VALUE;

        for (int end = 0; end < n; end++) {
            currentSum += nums[end];

            while (currentSum >= target) {
                minLen = Math.min(minLen, end - start + 1);
                currentSum -= nums[start];
                start++;
            }
        }

        return minLen == Integer.MAX_VALUE ? 0 : minLen;
    }

    public static void main(String[] args) {
        Solution solution = new Solution();
        int target = 7;
        int[] nums = { 2, 3, 1, 2, 4, 3 };

        int result = solution.minSubArrayLen(target, nums);
        System.out.println(result); 
    }
}
