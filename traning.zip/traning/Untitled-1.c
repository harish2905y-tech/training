
#include <stdio.h>

int main()
{
    int num = 10, i, n = 10;
    for (i = 0; i < n; i++)
    {
        printf("%d*%d = %d\n", num, i, num * i);
    }
    return 0;
}