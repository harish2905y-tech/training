#include <stdio.h>

void printPattern(int n, int i)
{
    if (i > n) 
        return;

    for (int j = 0; j < i; j++)
    {
        printf("*");
    }
    printf("\n");

    printPattern(n, i + 1); 
}

int main()
{
    int n=5;
    printPattern(n,1);
    return 0;
}
