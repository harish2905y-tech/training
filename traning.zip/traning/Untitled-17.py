def MaxMin(arr):
    max_element = max(arr)
    min_element = min(arr)
    return max_element, min_element


arr = [3, 1, 7, 4, 9, 2]
max, min = MaxMin(arr)
print(f"Maximum element: {max}")
print(f"Minimum element: {min}")
