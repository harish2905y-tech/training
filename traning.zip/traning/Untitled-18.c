#include <stdio.h>
int isSorted(int arr[], int n)
{
    if (n == 1 || n == 0)
    {
        return 1;
    }
    if (arr[0] > arr[1])
    {
        return 0;
    }
    return isSorted(arr + 1, n - 1);
}

int main()
{
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);
    int arr[n];
    printf("Enter %d elements: ", n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    if (isSorted(arr, n))
    {
        printf("The array is sorted.\n");
    }
    else
    {
        printf("The array is NOT sorted.\n");
    }

    return 0;
}
