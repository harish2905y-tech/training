#include <stdio.h>

void checkKthBit(int num, int k)
{
    if (num & (1 << (k - 1)))
    {
        printf("The %d-th bit is SET (1)\n", k);
    }
    else
    {
        printf("The %d-th bit is NOT SET (0)\n", k);
    }
}

int main()
{
    int num, k;
    printf("Enter a number: ");
    scanf("%d", &num);
    printf("Enter the bit position to check (starting from 1): ");
    scanf("%d", &k);

    checkKthBit(num, k);

    return 0;
}
