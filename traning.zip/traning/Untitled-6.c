#include <stdio.h>
int main()
{
    int a[] = {1, 2, 3, 4, 5, 6};
    int i, max = a[0], min = a[0];
    for (i = 0; i <= sizeof(a)/sizeof(a[0]); i++)
    {
        if (a[i] > max)
        {
            max = a[i];
        }
    }
    printf("Max = %d", max);
    return 0;
}