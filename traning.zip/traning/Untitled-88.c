num = 5 #Binary : 00000101 result = num << 2 #Left shift by 2 positions
                                    print(result) #Output : 20
