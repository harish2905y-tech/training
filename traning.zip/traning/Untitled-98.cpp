#include <iostream>
using namespace std;
int main()
{
    int maxfreq = 0; 
    int element = 0;
    int freq[] = {2, 4, 5, 7, 8, 7, 7};
    int max=freq[0];
    for (int i = 0; i <= max; i++)
    {
        if (freq[i] > maxfreq)
        {
            maxfreq = freq[i];
            element = i;
        }
    }
     cout << element;
     return 0;
}
