#include <stdio.h>

int factorial(int n)
{
    if (n < 1)
    {
        return 1;
    }
    else
    {
        return n * factorial(n -1);
    }
}

int main()
{

    int r = factorial(3);
    printf("Factorial: %d\n", r);

    return 0;
}

