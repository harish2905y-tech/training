public class prime{
    public static boolean checkprime(int n) {
        if (n <= 1) {
            return false;
        }
        if (n == 2) {
            return true;
        }
        for (int i = 0; i <= n / 2; i++) {
            if (n % i == 0) {
                return false;
            } 
        }

        return true;
 }


     public static void main (String[] args){
    int a=17;
    boolean result = checkprime(a);
    System.out.println(result);
  }
}